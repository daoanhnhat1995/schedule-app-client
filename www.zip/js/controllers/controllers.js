
angular.module('parse-starter.controllers',[]);