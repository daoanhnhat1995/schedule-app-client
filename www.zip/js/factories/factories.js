/**
 */
angular.module('parse-starter.factories',[]);
